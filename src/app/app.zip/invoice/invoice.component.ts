import { Component } from '@angular/core';

@Component({
  selector: 'osb-invoice',
  templateUrl: './invoice.component.html'
})
export class InvoiceComponent{
    
}
